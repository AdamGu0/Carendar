package info.leiguo.healthmonitoring.data;

/**
 * Created by lei on 3/23/17.
 */

public class PointData {
    public double x;
    public double y;
    public double z;
}

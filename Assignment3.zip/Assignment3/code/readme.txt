Assignment 3.

By Group 15:

Lei Guo
Zhenchao Cai
Chang Chu
Jingyang Guo

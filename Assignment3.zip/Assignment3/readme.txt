Assignment 3.

By Group 15:

Lei Guo
Zhenchao Cai
Chang Chu
Jingyang Guo


Inventory:

1. code -- all the code for this assignment.
2. partA.db -- the sample DB file created by part A.
3. Performance.jpg -- the graph which shows �Part B� execution time and power consumption 
4. screenshots -- some important screenshots


Usage:

1. Recording activities data:
   (1) Select activity type by pressing the spinner.
   (2) Press the RECORD DATA button to start recording data.

2. Classify the activities with SVM
   Press the ANALYZE button (the classification work is based on the database which we already generated, it is under res/raw folder).

3. Data Visualization
   Press the PLOT button (lines are drawn with OpenGL ES; red, green and blue lines for Eating, Walking and Running respectively).